/**
 * Created by Administrator on 2/8/2017.
 */

exports.delimitation = function (value, delimiter) {
    var data = value.split(delimiter);
    return data;
}
